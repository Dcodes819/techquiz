import { LampDemo } from './components/LampEffect';
import { RainbowButton } from './components/RainbowButton';

export default function Home() {
  return (
    <main className="min-h-screen relative">
      <LampDemo />
      <div className="absolute bottom-20 inset-x-0 flex items-center justify-center pointer-events-none">
        <div className="max-w-4xl w-full text-center z-50 pointer-events-auto">
          <RainbowButton 
            href="/categories" 
            className="text-base font-semibold"
          >
            Choose Category
          </RainbowButton>
        </div>
      </div>
    </main>
  );
} 