'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { fetchQuizQuestions, Question } from '@/lib/api';
import { getAllAnswers, decodeHTML } from '@/lib/utils';
import { getCategoryById } from '@/lib/categories';
import { BeamsBackground } from '@/app/components/BeamsBackground';
import { RainbowButton } from '@/app/components/RainbowButton';

export default function QuizPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const categoryId = searchParams.get('category') || 'random';
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quizComplete, setQuizComplete] = useState(false);

  useEffect(() => {
    const loadQuestions = async () => {
      try {
        setLoading(true);
        setError(null);
        console.log("Fetching quiz questions for category:", categoryId);
        
        const fetchedQuestions = await fetchQuizQuestions(10, categoryId);
        console.log("Fetched questions:", fetchedQuestions);
        
        if (!fetchedQuestions || fetchedQuestions.length === 0) {
          throw new Error('No questions available for this category');
        }
        
        setQuestions(fetchedQuestions);
      } catch (err) {
        console.error('Error loading questions:', err);
        setError(err instanceof Error ? err.message : 'Failed to load quiz questions');
      } finally {
        setLoading(false);
      }
    };

    loadQuestions();
  }, [categoryId]);

  const currentQuestion = questions[currentQuestionIndex];
  
  const handleAnswerSelection = (answer: string) => {
    setSelectedAnswer(answer);
  };

  const handleNextQuestion = () => {
    // Update score if correct
    if (selectedAnswer === currentQuestion.correct_answer) {
      setScore((prevScore: number) => prevScore + 1);
    }

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prevIndex: number) => prevIndex + 1);
      setSelectedAnswer(null);
    } else {
      setQuizComplete(true);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setScore(0);
    setQuizComplete(false);
    setLoading(true);
    
    // Reload questions
    fetchQuizQuestions(10, categoryId)
      .then(newQuestions => {
        console.log("Reloaded questions:", newQuestions.length);
        if (newQuestions.length === 0) {
          setError('No questions available for this category. Please try a different one.');
          setLoading(false);
          return;
        }
        
        setQuestions(newQuestions);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error reloading questions:', err);
        setError('Failed to load new questions. Please try again.');
        setLoading(false);
      });
  };

  const categoryName = getCategoryById(categoryId)?.name || 'Tech';
  
  if (loading) {
    return (
      <BeamsBackground intensity="subtle">
        <div className="flex min-h-screen items-center justify-center">
          <div className="w-16 h-16 border-4 border-primary-400 border-t-primary-700 rounded-full animate-spin"></div>
        </div>
      </BeamsBackground>
    );
  }

  if (error) {
    return (
      <BeamsBackground intensity="subtle">
        <div className="flex min-h-screen flex-col items-center justify-center p-4">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-6 py-4 rounded-lg shadow-lg">
            <p className="text-xl">{error}</p>
          </div>
          <div className="mt-6 flex gap-4">
            <RainbowButton 
              href="/categories" 
              className="text-base font-semibold"
            >
              Choose Different Category
            </RainbowButton>
            <button 
              onClick={() => router.push('/')}
              className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-semibold py-2 px-6 rounded-full border border-white/20 transition-colors"
            >
              Return Home
            </button>
          </div>
        </div>
      </BeamsBackground>
    );
  }

  if (quizComplete) {
    return (
      <BeamsBackground intensity="medium">
        <div className="flex min-h-screen flex-col items-center justify-center p-4">
          <div className="max-w-md w-full bg-white/10 backdrop-blur-md rounded-lg shadow-lg p-8 border border-white/20">
            <h1 className="text-3xl font-bold mb-4 text-white">Quiz Complete!</h1>
            <p className="text-2xl mb-8 text-gray-200">Your Score: {score} / {questions.length}</p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <RainbowButton 
                onClick={handleRestartQuiz}
                className="text-base font-semibold"
              >
                Try Again
              </RainbowButton>
              <button 
                onClick={() => router.push('/categories')}
                className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-semibold py-2 px-6 rounded-full border border-white/20 transition-colors"
              >
                Categories
              </button>
            </div>
          </div>
        </div>
      </BeamsBackground>
    );
  }

  if (!currentQuestion) {
    return (
      <BeamsBackground intensity="subtle">
        <div className="flex min-h-screen items-center justify-center">
          <p className="text-white text-xl">No questions available.</p>
        </div>
      </BeamsBackground>
    );
  }

  const answers = getAllAnswers(currentQuestion);

  return (
    <BeamsBackground intensity="strong">
      <div className="flex min-h-screen flex-col items-center justify-center p-4">
        <div className="absolute top-6 left-6 z-10">
          <button 
            onClick={() => router.push('/categories')}
            className="bg-white/10 backdrop-blur-md hover:bg-white/20 text-white font-semibold py-2 px-6 rounded-full border border-white/20 transition-colors flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back
          </button>
        </div>
        
        <div className="max-w-2xl w-full bg-white/10 backdrop-blur-md rounded-lg shadow-lg p-8 border border-white/20">
          <div className="flex justify-between items-center mb-6">
            <span className="font-semibold text-gray-300">
              Question {currentQuestionIndex + 1}/{questions.length}
            </span>
            <span className="font-semibold text-primary-400">
              Score: {score}
            </span>
          </div>
          
          <div className="mb-8">
            <span className="inline-block mb-2 px-3 py-1 bg-primary-900/50 text-primary-200 rounded-full text-sm">
              {decodeHTML(currentQuestion.category)}
            </span>
            <h2 className="text-xl font-bold mb-3 text-white">
              {decodeHTML(currentQuestion.question)}
            </h2>
            <div className="text-sm text-gray-300">
              Difficulty: {currentQuestion.difficulty.charAt(0).toUpperCase() + currentQuestion.difficulty.slice(1)}
            </div>
          </div>
          
          <div className="space-y-3 mb-6">
            {answers.map((answer, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelection(answer)}
                className={`w-full text-left p-4 rounded-lg border ${
                  selectedAnswer === answer
                    ? 'bg-primary-900/70 border-primary-400/70 text-white'
                    : 'border-white/20 hover:bg-white/10 text-gray-200'
                } transition-colors`}
              >
                {decodeHTML(answer)}
              </button>
            ))}
          </div>
          
          <button
            onClick={handleNextQuestion}
            disabled={selectedAnswer === null}
            className={`w-full py-3 rounded-full font-semibold ${
              selectedAnswer === null
                ? 'bg-gray-700/50 text-gray-400 cursor-not-allowed'
                : 'bg-primary-600 hover:bg-primary-700 text-white'
            } transition-colors`}
          >
            {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
          </button>
        </div>
      </div>
    </BeamsBackground>
  );
} 