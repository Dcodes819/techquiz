# Tech Quiz App

A modern web application for tech professionals to test their knowledge and stay current with the latest technologies.

## Features

- Interactive quizzes on various tech topics
- User authentication and profile management
- Progress tracking and performance statistics
- Leaderboards and social sharing
- Mobile-responsive design

## Tech Stack

- **Frontend**: Next.js, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API routes
- **Database**: MongoDB with Mongoose
- **Authentication**: NextAuth.js
- **Styling**: Tailwind CSS

## Getting Started

### Prerequisites

- Node.js 16.x or higher
- npm or yarn
- MongoDB (local or Atlas)

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/tech-quiz-app.git
cd tech-quiz-app
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Set up environment variables
```bash
cp .env.example .env.local
```
Edit `.env.local` with your configuration values.

4. Run the development server
```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

```
/
├── app/             # Next.js app directory
├── components/      # React components
├── lib/            # Utility functions and hooks
├── models/         # Mongoose models
├── public/         # Static assets
├── styles/         # Global CSS 
└── types/          # TypeScript type definitions
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License. 